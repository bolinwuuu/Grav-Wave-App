import UIKit
import Accelerate


func run_chirp(mass1:Float, mass2:Float, runMode:Int) {
    
    print("Entered run_chirp with\nMass1 = " + String(mass1) + "\nMass2 = " + String(mass2) + "\nRunMode = " + String(runMode) + "\n");

    // var option:Int = 5;
    var m1:Float = mass1;
    var m2:Float = mass2;
    /*
    if (option == 1) {
        
    // Neutron star masses:
        
        m1 = 1.4;
        m2 = 1.4;
    } else if (option == 2) {
        
    // Light black holes:
        
        m1 = 5;
        m2 = 5;
    } else if (option==3) {

    // Typical black holes:

        m1 = 10;
        m2 = 10;
    } else if (option == 4) {

    // Heavy black holes:

        m1 = 30;
        m2 = 30;
    } else if (option == 5) {

    // Customized:

        m1 = 5;
        m2 = 20;
    }*/

    // Implied chirp mass (governs frequency and amplitude evolution)
    // (PPNP text right after Eqn 74)
      
    var mchirp:Float = pow((m1*m2),(3/5))/pow((m1+m2),(1/5));

    // Physical constants

    let g:Float = 6.67e-11;
    let c:Float = 2.998e8;
    let pc:Float = 3.086e16;
    let msun:Float = 2.0e30;

    // Compute Schwarzchild radii of stars

    var r1 = 2 * g * m1 * msun / pow(c, 2);
    var r2 = 2 * g * m2 * msun / pow(c, 2);

    // Frequency coefficient
    // (Based on PPNP Eqn 73)

    var fcoeff:Float = (1/(8*Float.pi)) * pow(pow(5, 3), 1/8) * pow(pow(c, 3) / (g*mchirp*msun), 5/8);

    // Amplitude coefficient (assume source at 15 Mpc)
    // (Based on PPNP Eqn 74)

    var rMpc:Float = 15;
    var r = rMpc * 1e6 * pc;
    var hcoeff = (1/r) * pow(5*pow(g*mchirp*msun/pow(c, 2), 5)/c, 1/4);

    // Amplitude rescaling parameter

    let hscale = 1e21;

    // frequency (Hz) when signal enters detector band

    let fbandlo:Float = 30;

    // Compute time remaining to coalescence from entering band
    // (Based on PPNP Eqn 73)

    var tau = pow(fcoeff/fbandlo, 8/3);

    // Debugging summary

    print("Starting chirp simulation with M1, M2, Mchirp = " + String(m1) + " " + String(m2) + " " + String(mchirp) + " " + "(Msun)");
    print("--> Schwarzchild radii = " + String(r1) + " " + String(r2) + "m");
    print("Distance to source r = " + String(rMpc) + " Mpc");
    print("Detection band low frequency = " + String(fbandlo) + "Hz\n--> Time to coalescence = " + String(tau) + " s\n");

    // Sampling rate (Hz) - fixed at 48 kHz for mp4 output

    let fsamp:Float = 48000;
    var dt = 1/fsamp;

    // Length of time to simulate (round up to nearest tenth of an integer second and add a tenth)

    var upperT = Float(ceil(10*Double(tau))/10 + 0.1);

    // Create time sample container

    var upperN = Float(floor(fsamp*upperT));
    //var t = Array(0...Int(upperN)-1);
    var t = Array(stride(from: 0, through: upperN-1, by: 1));
    vDSP.multiply(dt, t);

    // Determine frequency (and then time) when Schwarzchild radii touch
    // (Use Kepler's 3rd law)
    // (Double orbital frequency to get GW frequency)

    var ftouch = 2 * (1/(2*Float.pi)) * pow(g*(m1+m2)*msun/pow(r1+r2,3), 1/2);
    var tautouch = pow(fcoeff/ftouch, 8/3);
    print("GW frequency when Schwarzchild radii touch: " + String(ftouch) + " Hz\n--> Occurs " + String(tautouch) + " seconds before point-mass coalescence\n");
    
    // Create frequency value vs time (up to last time sample before point-mass coalescence)
    // (Based on PPNP Eqn 73)
    
    var freq = [Float](repeating: 0, count: t.count);
    
    
    
}

run_chirp(mass1: 5, mass2: 20, runMode: 2);











